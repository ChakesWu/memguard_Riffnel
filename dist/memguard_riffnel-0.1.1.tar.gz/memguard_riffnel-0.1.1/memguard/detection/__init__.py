# Detection pipeline and detectors
