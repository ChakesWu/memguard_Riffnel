# Framework adapters
